All images come with a DFSG-compatible license:
sunflower headimage:	(c) 2012 Henner Zeller CC-BY-SA 4.0 https://flickr.com/photos/hzeller/6887583114/ (also a crop of it in the 'glitchy' example)
ldgraphy image:		(c) 2017 Henner Zeller CC-BY-SA 4.0 https://github.com/hzeller/ldgraphy/blob/master/img/pocket-cape.jpg
opamp.png:		GPLv3 https://gitlab.com/kicad/code/kicad/-/blob/master/bitmaps_png/png/icon_libedit_32_32.png
mondrian-cake.jpg:	(c) 2012 Henner Zeller CC-BY-SA 4.0
rocket-ccc2019.jpg:	(c) 2019 Henner Zeller CC-BY-SA 4.0
spooning-chili.nef:	(c) 2010 Henner Zeller CC-BY-SA 4.0
loupe-fingerprint:	LGPL-3.0 https://gitlab.freedesktop.org/libfprint/fprint.freedesktop.org/-/blob/master/images/Fprint_logo.png
soccer ball:		CC-BY-SA 3.0 https://commons.wikimedia.org/wiki/File:Simple_Soccer_Ball.svg
