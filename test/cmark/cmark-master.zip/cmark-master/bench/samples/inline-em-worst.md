*this *is *a *worst *case *for *em *backtracking

__this __is __a __worst __case __for __em __backtracking

***this ***is ***a ***worst ***case ***for ***em ***backtracking
